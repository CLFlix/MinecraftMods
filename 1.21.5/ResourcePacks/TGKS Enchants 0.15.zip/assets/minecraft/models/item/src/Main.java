import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        String[] str1= new String[]{"w", "s", "i", "g", "d", "n"};
        String[] str2= new String[]{"a", "p", "s", "w", "h"};
        String[] str3= new String[]{"m", "f", "s", "mf", "ms"};

        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 5; j++) {
                for(int k = 0; k < 5; k++) {
                    String strName = str1[i] + str2[j] + str3[k];
                    File myObj = new File(strName+".json");
                    FileWriter myWriter = null;
                    try {
                        myWriter = new FileWriter(strName+".json");

                        String strC = "{\"parent\":\"minecraft:item/handheld\",\"textures\": {\"layer0\": \"minecraft:item/"+str1[i]+str2[j]+str3[k]+"\"}}";
                        myWriter.write(strC);
                        System.out.println(strC);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    myWriter.close();
                }
            }
        }
    }
}